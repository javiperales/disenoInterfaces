$(document).ready(function(){
    $(".burger").click(function(){
        $(".vertical").slideToggle();
    })
    
    });